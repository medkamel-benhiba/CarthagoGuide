import 'dart:async';
import 'package:CarthagoGuide/models/chat_message.dart';

String generateChatResponse(String message) {
  final lowerMessage = message.toLowerCase();

  if (lowerMessage.contains('hotel') || lowerMessage.contains('hôtel')) {
    return "Je serais ravi de vous aider à trouver des hôtels ! La Tunisie dispose d'hébergements exceptionnels, des complexes de luxe à Hammamet aux charmants riads de la Médina. Quel est votre emplacement préféré ?";
  } else if (lowerMessage.contains('restaurant')) {
    return "Miam ! La cuisine tunisienne est délicieuse. Cherchez-vous des fruits de mer frais, un restaurant traditionnel du centre-ville ou un café moderne ?";
  } else if (lowerMessage.contains('médina') || lowerMessage.contains('histoire')) {
    return "La Médina de Tunis est fascinante, tout comme Carthage ! Voulez-vous connaître les heures d'ouverture, des faits historiques ou des visites guidées disponibles ?";
  } else {
    return "C'est une excellente question ! Je peux vous aider à découvrir les meilleurs hôtels, restaurants, destinations touristiques et circuits de voyage en Tunisie. Qu'aimeriez-vous explorer ?";
  }
}

Future<ChatMessage> getAssistantResponse(String userMessage) async {
  await Future.delayed(const Duration(seconds: 2));

  final responseText = generateChatResponse(userMessage);

  return ChatMessage(
    text: responseText,
    isUser: false,
    timestamp: DateTime.now(),
  );
}