import 'package:carthagoguide/screens/hotelDetails_screen.dart';
import 'package:carthagoguide/widgets/hotels/filters/filter_section.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:carthagoguide/constants/theme.dart';
import 'package:carthagoguide/widgets/hotels/hotel_card.dart';
import 'package:carthagoguide/providers/hotel_provider.dart'; // NEW
import 'package:carthagoguide/models/hotel.dart'; // NEW

import '../widgets/hotels/hotel_searchbar.dart';


class HotelsScreen extends StatefulWidget {
  final VoidCallback? onMenuTap;

  const HotelsScreen({super.key, this.onMenuTap});

  @override
  State<HotelsScreen> createState() => _HotelsScreenState();
}

class _HotelsScreenState extends State<HotelsScreen> {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<HotelProvider>(context, listen: false).fetchAllHotels();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context).currentTheme;
    // Get current locale for multi-language support in the list items
    final locale = Localizations.localeOf(context);

    return Scaffold(
      backgroundColor: theme.background,
      appBar: AppBar(
        backgroundColor: theme.background,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.menu_rounded, color: theme.text),
          onPressed: widget.onMenuTap,
        ),
        title: Text(
          "Hôtels",
          style: TextStyle(color: theme.primary, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Consumer<HotelProvider>(
        builder: (context, hotelProvider, child) {
          final List<Hotel> hotelsList = hotelProvider.allHotels;

          if (hotelProvider.isLoading && hotelsList.isEmpty) {
            return Center(child: CircularProgressIndicator(color: theme.primary));
          }

          if (hotelsList.isEmpty && !hotelProvider.isLoading) {
            // Show message if no hotels are found after loading
            return Center(child: Text(
              "Aucun hôtel trouvé.",
              style: TextStyle(color: theme.text.withOpacity(0.7)),
            ));
          }

          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SearchBarWidget(theme: theme),
                  const SizedBox(height: 25),
                  FilterSection(theme: theme, type: FilterType.hotel),
                  const SizedBox(height: 25),
                  Text(
                    "Résultats (${hotelsList.length})",
                    style: TextStyle(
                      color: theme.text.withOpacity(0.6),
                      fontWeight: FontWeight.w300,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 15),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: hotelsList.length,
                    itemBuilder: (context, index) {
                      final hotel = hotelsList[index];

                      return HotelCardWidget(
                        theme: theme,
                        title: hotel.name,
                        destination: hotel.destinationName ?? 'Destination Inconnue',
                        imgUrl: hotel.images!.first ?? hotel.cover ?? "assets/images/placeholder.jpg",
                        rating: hotel.categoryCode?.toDouble() ?? 3.0,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => HotelDetailsScreen(
                                hotel: hotel,
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                  Center(
                    child: TextButton(
                      onPressed: () {
                        // TODO: Implement load more/pagination using hotelProvider's search/pagination logic
                      },
                      child: Text(
                        "Afficher plus d'hôtels",
                        style: TextStyle(color: theme.primary),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}