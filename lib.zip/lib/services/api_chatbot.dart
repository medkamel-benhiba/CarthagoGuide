import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:CarthagoGuide/models/chat_message.dart';

class ChatService {
  final String baseUrl = 'http://79.137.78.79:3333';
  String? _sessionId;
  String? _userId;

  // Configurable timeout duration
  static const Duration requestTimeout = Duration(seconds: 60);

  Future<void> initialize() async {
    _sessionId = 'session_${DateTime.now().millisecondsSinceEpoch}';
    _userId = 'user_${DateTime.now().millisecondsSinceEpoch}';
  }

  /// Send a message with proper timeout and error handling
  Future<Map<String, dynamic>> sendMessage(String message) async {
    try {
      final response = await http
          .post(
        Uri.parse('$baseUrl/chat'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'message': message,
          'session_id': _sessionId,
          'user_id': _userId,
        }),
      )
          .timeout(
        requestTimeout,
        onTimeout: () {
          throw TimeoutException(
            'La connexion a pris trop de temps. Veuillez réessayer.',
          );
        },
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body) as Map<String, dynamic>;
      } else if (response.statusCode == 408) {
        throw TimeoutException('Le serveur a mis trop de temps à répondre.');
      } else if (response.statusCode >= 500) {
        throw Exception('Erreur du serveur (${response.statusCode}). Veuillez réessayer plus tard.');
      } else {
        throw Exception('Erreur: ${response.statusCode} - ${response.body}');
      }
    } on TimeoutException catch (e) {
      throw Exception('Délai d\'attente dépassé: ${e.message}');
    } on http.ClientException catch (e) {
      // This is the error you're experiencing
      throw Exception('Erreur de connexion: ${e.message}. Vérifiez votre connexion Internet.');
    } on FormatException catch (e) {
      throw Exception('Réponse invalide du serveur: ${e.message}');
    } catch (e) {
      throw Exception('Erreur inattendue: $e');
    }
  }

  /// Start a new conversation
  void startNewConversation() {
    _sessionId = 'session_${DateTime.now().millisecondsSinceEpoch}';
  }

  /// Get conversation history with timeout
  Future<List<Map<String, dynamic>>> getConversationHistory() async {
    try {
      final response = await http
          .post(
        Uri.parse('$baseUrl/conversations/history'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'user_id': _userId,
        }),
      )
          .timeout(requestTimeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['conversations'] ?? []);
      } else {
        throw Exception('Failed to load history: ${response.statusCode}');
      }
    } on TimeoutException {
      throw Exception('Timeout loading conversation history');
    } on http.ClientException catch (e) {
      throw Exception('Connection error loading history: ${e.message}');
    } catch (e) {
      throw Exception('Error loading history: $e');
    }
  }

  /// Load a specific conversation with timeout
  Future<Map<String, dynamic>> loadConversation(String sessionId) async {
    try {
      final response = await http
          .post(
        Uri.parse('$baseUrl/conversations/load'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'session_id': sessionId,
          'user_id': _userId,
        }),
      )
          .timeout(requestTimeout);

      if (response.statusCode == 200) {
        _sessionId = sessionId;
        return jsonDecode(response.body) as Map<String, dynamic>;
      } else {
        throw Exception('Failed to load conversation: ${response.statusCode}');
      }
    } on TimeoutException {
      throw Exception('Timeout loading conversation');
    } on http.ClientException catch (e) {
      throw Exception('Connection error: ${e.message}');
    } catch (e) {
      throw Exception('Error loading conversation: $e');
    }
  }

  /// Delete a conversation with timeout
  Future<void> deleteConversation(String sessionId) async {
    try {
      final response = await http
          .post(
        Uri.parse('$baseUrl/conversations/delete'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'session_id': sessionId,
          'user_id': _userId,
        }),
      )
          .timeout(requestTimeout);

      if (response.statusCode != 200) {
        throw Exception('Failed to delete conversation: ${response.statusCode}');
      }
    } on TimeoutException {
      throw Exception('Timeout deleting conversation');
    } on http.ClientException catch (e) {
      throw Exception('Connection error: ${e.message}');
    } catch (e) {
      throw Exception('Error deleting conversation: $e');
    }
  }

  /// Convert conversation data to ChatMessage list
  List<ChatMessage> conversationToMessages(Map<String, dynamic> conversation) {
    final messages = <ChatMessage>[];

    if (conversation.containsKey('messages')) {
      final messageList = conversation['messages'] as List;

      for (var msg in messageList) {
        messages.add(
          ChatMessage(
            text: msg['text'] ?? '',
            isUser: msg['is_user'] ?? false,
            timestamp: DateTime.parse(
              msg['timestamp'] ?? DateTime.now().toIso8601String(),
            ),
            isMarkdown: msg['is_markdown'] ?? !(msg['is_user'] ?? false),
          ),
        );
      }
    }

    return messages;
  }

  String? get currentSessionId => _sessionId;
  String? get currentUserId => _userId;
}