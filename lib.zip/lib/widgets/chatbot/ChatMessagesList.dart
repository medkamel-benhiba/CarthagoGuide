import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:CarthagoGuide/models/chat_message.dart';

class ChatMessagesList extends StatelessWidget {
  final ScrollController scrollController;
  final List<ChatMessage> messages;
  final bool isTyping;
  final AnimationController typingController;

  const ChatMessagesList({
    super.key,
    required this.scrollController,
    required this.messages,
    required this.isTyping,
    required this.typingController,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
        controller: scrollController,
        padding: const EdgeInsets.all(16),
        itemCount: messages.length + (isTyping ? 1 : 0),
        itemBuilder: (context, index) {
          if (index == messages.length) {
            return _buildTypingIndicator();
          }

          final message = messages[index];
          return _buildMessageBubble(context, message);
        },
      ),
    );
  }

  Widget _buildMessageBubble(BuildContext context, ChatMessage message) {
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.85,
        ),
        child: message.isMarkdown && !message.isUser
            ? _buildMarkdownWithCards(context, message)
            : _buildSimpleMessage(context, message),
      ),
    );
  }

  Widget _buildSimpleMessage(BuildContext context, ChatMessage message) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: message.isUser ? Theme.of(context).primaryColor : Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(
        message.text,
        style: TextStyle(
          color: message.isUser ? Colors.white : Colors.black87,
          fontSize: 15,
        ),
      ),
    );
  }

  Widget _buildMarkdownWithCards(BuildContext context, ChatMessage message) {
    final parsedContent = _parseMarkdownContent(message.text);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: parsedContent.map((content) {
        if (content['type'] == 'table') {
          return _buildTableAsCards(context, content['data']);
        } else {
          return _buildMarkdownSection(context, content['data']);
        }
      }).toList(),
    );
  }

  Widget _buildMarkdownSection(BuildContext context, String markdown) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: MarkdownBody(
        data: markdown,
        styleSheet: MarkdownStyleSheet(
          p: const TextStyle(
            color: Colors.black87,
            fontSize: 15,
          ),
          h1: const TextStyle(
            color: Colors.black87,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
          h2: const TextStyle(
            color: Colors.black87,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          h3: const TextStyle(
            color: Colors.black87,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
          listBullet: const TextStyle(
            color: Colors.black87,
          ),
          blockquote: const TextStyle(
            color: Colors.black54,
            fontStyle: FontStyle.italic,
          ),
        ),
        selectable: true,
      ),
    );
  }

  Widget _buildTableAsCards(BuildContext context, List<Map<String, dynamic>> tableData) {
    return Column(
      children: tableData.map((row) {
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: row.entries.map((entry) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 2,
                        child: Text(
                          entry.key,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        flex: 3,
                        child: Text(
                          entry.value.toString(),
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        );
      }).toList(),
    );
  }

  List<Map<String, dynamic>> _parseMarkdownContent(String markdown) {
    final List<Map<String, dynamic>> content = [];
    final lines = markdown.split('\n');

    List<String> currentSection = [];
    List<String> tableLines = [];
    bool inTable = false;

    for (int i = 0; i < lines.length; i++) {
      final line = lines[i].trim();

      // Detect table start (line with pipes)
      if (line.contains('|') && !inTable) {
        // Save previous section if exists
        if (currentSection.isNotEmpty) {
          content.add({
            'type': 'markdown',
            'data': currentSection.join('\n'),
          });
          currentSection = [];
        }
        inTable = true;
        tableLines.add(line);
      } else if (line.contains('|') && inTable) {
        tableLines.add(line);
      } else if (inTable && !line.contains('|')) {
        // Table ended
        if (tableLines.length > 2) {
          final tableData = _parseTable(tableLines);
          if (tableData.isNotEmpty) {
            content.add({
              'type': 'table',
              'data': tableData,
            });
          }
        }
        tableLines = [];
        inTable = false;
        currentSection.add(line);
      } else {
        currentSection.add(line);
      }
    }

    // Add remaining content
    if (inTable && tableLines.length > 2) {
      final tableData = _parseTable(tableLines);
      if (tableData.isNotEmpty) {
        content.add({
          'type': 'table',
          'data': tableData,
        });
      }
    } else if (currentSection.isNotEmpty) {
      content.add({
        'type': 'markdown',
        'data': currentSection.join('\n'),
      });
    }

    return content;
  }

  List<Map<String, dynamic>> _parseTable(List<String> tableLines) {
    if (tableLines.length < 2) return [];

    // Extract headers (first line)
    final headers = tableLines[0]
        .split('|')
        .map((h) => h.trim())
        .where((h) => h.isNotEmpty)
        .toList();

    // Skip separator line (second line with dashes)
    // Parse data rows (from third line onwards)
    final List<Map<String, dynamic>> rows = [];

    for (int i = 2; i < tableLines.length; i++) {
      final cells = tableLines[i]
          .split('|')
          .map((c) => c.trim())
          .where((c) => c.isNotEmpty)
          .toList();

      if (cells.length == headers.length) {
        final Map<String, dynamic> row = {};
        for (int j = 0; j < headers.length; j++) {
          row[headers[j]] = cells[j];
        }
        rows.add(row);
      }
    }

    return rows;
  }

  Widget _buildTypingIndicator() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildDot(0),
            const SizedBox(width: 4),
            _buildDot(1),
            const SizedBox(width: 4),
            _buildDot(2),
          ],
        ),
      ),
    );
  }

  Widget _buildDot(int index) {
    return AnimatedBuilder(
      animation: typingController,
      builder: (context, child) {
        final value = (typingController.value + (index * 0.33)) % 1.0;
        return Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: Colors.grey.withOpacity(0.3 + (value * 0.7)),
            shape: BoxShape.circle,
          ),
        );
      },
    );
  }
}