import 'package:flutter/material.dart';
import 'package:CarthagoGuide/models/chat_message.dart';
import 'package:CarthagoGuide/services/api_chatbot.dart';

class ChatHelpers {
  /// Scroll to the bottom of the chat
  static void scrollToBottom(ScrollController scrollController) {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (scrollController.hasClients) {
        scrollController.animateTo(
          scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  /// Handle quick chip tap
  static String handleQuickChipTap(String label) {
    return label.replaceAll(RegExp(r'[^\w\s]'), '');
  }

  /// Send a message and handle the response with retry logic
  static Future<void> sendMessage({
    required String message,
    required ChatService chatService,
    required Function(ChatMessage) onAddMessage,
    required Function(bool) onTypingChange,
    required VoidCallback onScrollToBottom,
    required Function(String) onError,
    int maxRetries = 2,
  }) async {
    // Add user message
    final userMessage = ChatMessage(
      text: message,
      isUser: true,
      timestamp: DateTime.now(),
      isMarkdown: false,
    );
    onAddMessage(userMessage);
    onScrollToBottom();

    // Show typing indicator
    onTypingChange(true);

    int retryCount = 0;
    while (retryCount <= maxRetries) {
      try {
        final response = await chatService.sendMessage(message);

        // Hide typing indicator
        onTypingChange(false);

        final String botResponse = response['response'] ??
            'Désolé, je n\'ai pas compris.';

        // Add bot message with Markdown support
        final botMessage = ChatMessage(
          text: botResponse,
          isUser: false,
          timestamp: DateTime.now(),
          isMarkdown: true,
        );
        onAddMessage(botMessage);
        onScrollToBottom();

        return; // Success - exit the function

      } catch (e) {
        retryCount++;

        if (retryCount > maxRetries) {
          // All retries failed
          onTypingChange(false);

          // Provide user-friendly error message
          String errorMessage;
          if (e.toString().contains('Timeout') ||
              e.toString().contains('Délai')) {
            errorMessage = 'Le serveur prend trop de temps à répondre. Veuillez réessayer.';
          } else if (e.toString().contains('Connection') ||
              e.toString().contains('connexion')) {
            errorMessage = 'Problème de connexion. Vérifiez votre Internet.';
          } else {
            errorMessage = 'Une erreur s\'est produite. Veuillez réessayer.';
          }

          onError(errorMessage);

          // Add error message to chat
          final errorBotMessage = ChatMessage(
            text: '❌ $errorMessage',
            isUser: false,
            timestamp: DateTime.now(),
            isMarkdown: false,
          );
          onAddMessage(errorBotMessage);
          onScrollToBottom();

          return;
        }

        // Wait before retrying
        await Future.delayed(Duration(seconds: retryCount * 2));
      }
    }
  }

  /// Start a new conversation
  static List<ChatMessage> startNewConversation(ChatService chatService) {
    chatService.startNewConversation();
    return [
      ChatMessage(
        text: "Bonjour ! Je suis votre assistant Carthago Guide. Comment puis-je vous aider à explorer la Tunisie aujourd'hui ?",
        isUser: false,
        timestamp: DateTime.now(),
        isMarkdown: false,
      )
    ];
  }

  /// Show conversation history bottom sheet
  static Future<void> showConversationHistory({
    required BuildContext context,
    required ChatService chatService,
    required Function(String) onLoadConversation,
  }) async {
    try {
      final conversations = await chatService.getConversationHistory();

      if (!context.mounted) return;

      showModalBottomSheet(
        context: context,
        builder: (context) => Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Historique des Conversations',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: conversations.isEmpty
                    ? const Center(
                  child: Text('Aucun historique de conversation'),
                )
                    : ListView.builder(
                  itemCount: conversations.length,
                  itemBuilder: (context, index) {
                    final conv = conversations[index];
                    return ListTile(
                      title: Text(conv['title'] ?? 'Conversation'),
                      subtitle: Text(
                        'Mis à jour: ${conv['updated_at'] ?? ''}',
                        style: const TextStyle(fontSize: 12),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        onLoadConversation(conv['session_id']);
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () async {
                          try {
                            await chatService.deleteConversation(
                              conv['session_id'],
                            );
                            Navigator.pop(context);
                            showConversationHistory(
                              context: context,
                              chatService: chatService,
                              onLoadConversation: onLoadConversation,
                            );
                          } catch (e) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Erreur de suppression: $e'),
                                ),
                              );
                            }
                          }
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur de chargement: $e')),
        );
      }
    }
  }

  /// Load a specific conversation
  static Future<List<ChatMessage>?> loadConversation({
    required BuildContext context,
    required ChatService chatService,
    required String sessionId,
  }) async {
    try {
      final conversation = await chatService.loadConversation(sessionId);
      return chatService.conversationToMessages(conversation);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur de chargement de la conversation: $e'),
          ),
        );
      }
      return null;
    }
  }
}